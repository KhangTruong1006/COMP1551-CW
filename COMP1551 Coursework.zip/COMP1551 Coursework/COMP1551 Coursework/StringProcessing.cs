﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.VisualBasic.Devices;

namespace COMP1551_Coursework
{
    internal class StringProcessing
    {
        Settings settings = new Settings();

        private string originalString;
        private int shiftValue;
        private string inputKeyword;

        public bool stringError = false;
        public bool stringLengthError = false;
        public bool shiftRangeError = false;
        public bool keywordError = false;
        public bool keywordLengthError = false;

        public StringProcessing(string originalString, string KeyValue, int MethodID)
        {

            // Check certain type of string
            // [A-Z]+$ mean only capital letters
            if (!Regex.IsMatch(originalString, @"^[A-Z]+$"))
            {
                stringError = true;
            }

            // check string length
            if (originalString.Length > settings.StringMaxLength)
            {
                stringLengthError = true;
            }

            // check shift value range between -25 and 25
            switch (MethodID)
            {
                case 0:
                    int shiftValue = int.Parse(KeyValue);
                    if (shiftValue < settings.MinShiftingValue || shiftValue > settings.MaxShiftingValue)
                    {
                        shiftRangeError = true;
                    }

                    else
                    {
                        setString(originalString);
                        this.shiftValue = shiftValue;
                    }
                break;

                case 1:
                    if (!Regex.IsMatch(KeyValue, @"^[A-Z]+$"))
                    {
                        keywordError = true;
                    }
                    if (KeyValue.Length > originalString.Length)
                    {
                        keywordLengthError = true;
                    }
                    else
                    {
                        setString(originalString);
                        this.inputKeyword = KeyValue;
                    }
                    break;
            }

        }
        private void setString(string originalString)
        {
            this.originalString = originalString;
        }

       
        // Caesar Cipher
        public string encodeCaesarCipher() 
        {
            string encryptedString = "";
            foreach (char c in originalString)
            {
                char ch = (char)((((c + shiftValue - 'A') % 26 + 26) % 26) + 'A');
                encryptedString += ch;
            }
            return encryptedString;
        }

        // Vigenère Cipher
        public string encodeVigenereCipher()
        {
            int stringLength = originalString.Length;
            string key = generateKey(inputKeyword, stringLength);
            string encryptedString = "";

            for (int i = 0; i < stringLength; i++)
            {
                int ASCII_Num = (originalString[i] + key[i]) % 26;
                ASCII_Num += 'A';
                encryptedString += (char)(ASCII_Num);
            }

            return encryptedString;
        }

        // generate key having length that equal to original string length
        //Input: HELLO - Keywork: HI 
        //Key  : HIHIH
        private string generateKey(string keyword, int stringLength)
        {
            for (int i = 0; ; i++)
            {
                if (stringLength == i)
                {
                    i = 0;
                }
                if (keyword.Length == stringLength)
                {
                    break;
                }
                keyword += (keyword[i]);

            }
            return keyword;
        }

        private int[] listASCII(string originalText)
        {
            int StringLength = originalText.Length;
            int[] ASCIIcharacters = new int[StringLength];
            for (int i = 0; i < StringLength; ++i)
            {
                ASCIIcharacters[i] = originalText[i];
            }
            return ASCIIcharacters;
            
        }

        // method InputCode
        public int[] listInputASCII()
        {
            int[] inputCodeCharacters = listASCII(originalString);
            return inputCodeCharacters;
        }

        // method OutputCode
        public int[] listOutputASCII(string encodedString) 
        {
            int[] outputCodeCharacters = listASCII(encodedString);
            return outputCodeCharacters;
        }

        public char[] sortString()
        {
            int StringLength = originalString.Length;
            char[] sortedString = new char[StringLength];
            for (int i = 0;i < StringLength; ++i)
            {
                sortedString[i] = originalString[i];
            }
            Array.Sort(sortedString);
            return sortedString;
        }
    }
}
