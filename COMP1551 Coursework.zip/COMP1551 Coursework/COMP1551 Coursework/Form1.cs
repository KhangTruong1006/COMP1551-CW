namespace COMP1551_Coursework
{
    public partial class Form1 : Form
    {
        Settings settings = new Settings();
        public Form1()
        {
            InitializeComponent();
            btnEncrypt.Enabled = false;

            // set default method
            CBEncryptMethod.SelectedIndex = 0;

        }


        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            try
            {
                int MethodID = CBEncryptMethod.SelectedIndex;
                string plainString = tbString.Text.Trim(); // Trim white space
                string KeyValue = tbKeyValue.Text.Trim(); // Trim white space


                StringProcessing stringProcessing = new StringProcessing(plainString, KeyValue,MethodID);

                // check any error
                if (stringProcessing.stringError || stringProcessing.stringLengthError || stringProcessing.shiftRangeError || stringProcessing.keywordError || stringProcessing.keywordLengthError)
                {
                    if (stringProcessing.stringError)
                    {
                        lblStringError.Text = settings.CapitalOnlyMessage;
                    }
                    if (stringProcessing.stringLengthError)
                    {
                        lblStringError.Text = settings.MaxStringMessage;
                    }
                    if (stringProcessing.shiftRangeError)
                    {
                        lblKeyValueError.Text = settings.ShiftValueErrorMessage;
                    }
                    if (stringProcessing.keywordError)
                    {
                        lblKeyValueError.Text = settings.KeywordErrorMessage;
                    }
                    if (stringProcessing.keywordLengthError)
                    {
                        lblKeyValueError.Text = settings.KeywordLengthErrorMessage;
                    }
                }

                else
                {
                    clearErrorMessages();
                    clearResultBoxes();

                    switch (MethodID)
                    {
                        case 0:
                            tbResult.Text = stringProcessing.encodeCaesarCipher();
                            break;
                        case 1:
                            tbResult.Text = stringProcessing.encodeVigenereCipher();
                            break;
                    }

                    // Input ASCII numbers
                    int[] inputCodeList = stringProcessing.listInputASCII();
                    
                    foreach (int c in inputCodeList)
                    {
                        tbInputCode.Text += c.ToString() + " ";
                    }

                    // Output ASCII numbers
                    int[] outputCodeList = stringProcessing.listOutputASCII(tbResult.Text);
                    foreach (int c in outputCodeList)
                    {
                        tbOutputCode.Text += c.ToString() + " ";
                    }

                    // Sort String Characters
                    char[] sortedString = stringProcessing.sortString();
                    foreach (char c in sortedString)
                    {
                        tbSortedString.Text += c;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"System Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
        
        private void CBEncryptMethod_SelectedIndexChanged(object sender, EventArgs e)
        {
            tbKeyValue.Text = "";
            switch (CBEncryptMethod.SelectedIndex) 
            { 
                case 0:
                    setLabel_HintText("Shift Value", "between -25 and 25");
                    break;
                case 1:
                    setLabel_HintText("Keyword", "HELLO");
                    break;
            }
        }
        private void clearResultBoxes()
        {
            tbResult.Text = "";
            tbInputCode.Text = "";
            tbOutputCode.Text = "";
            tbSortedString.Text = "";
        }

        private void clearErrorMessages()
        {
            lblError.Text = "";
            lblStringError.Text = "";
            lblKeyValueError.Text = "";
        }
        private void setLabel_HintText(string LabelName, string HintText)
        {
            lblShiftValue.Text = LabelName;
            tbKeyValue.PlaceholderText = HintText;
        }


        private void Form1_TextChanged(object sender, EventArgs e)
        {
            if (tbString.Text != "" && tbKeyValue.Text != "")
            {

                btnEncrypt.Enabled = true;
            }

            else
            {
                btnEncrypt.Enabled = false;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            tbString.Text = "";
            tbKeyValue.Text = "";

            clearErrorMessages();
            clearResultBoxes();
        }



        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

    }
}
