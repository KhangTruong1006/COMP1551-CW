﻿namespace COMP1551_Coursework
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblString = new Label();
            tbString = new TextBox();
            tbKeyValue = new TextBox();
            lblShiftValue = new Label();
            lblencryptedString = new Label();
            btnEncrypt = new Button();
            label1 = new Label();
            tbResult = new TextBox();
            lblError = new Label();
            btnClear = new Button();
            tbInputCode = new TextBox();
            tbOutputCode = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label4 = new Label();
            tbSortedString = new TextBox();
            label5 = new Label();
            CBEncryptMethod = new ComboBox();
            label6 = new Label();
            lblStringError = new Label();
            lblKeyValueError = new Label();
            SuspendLayout();
            // 
            // lblString
            // 
            lblString.AutoSize = true;
            lblString.Font = new Font("Roboto", 12F);
            lblString.Location = new Point(129, 126);
            lblString.Name = "lblString";
            lblString.Size = new Size(134, 24);
            lblString.TabIndex = 0;
            lblString.Text = "Encrypt String";
            // 
            // tbString
            // 
            tbString.Location = new Point(286, 125);
            tbString.Name = "tbString";
            tbString.PlaceholderText = "only capitalised letters";
            tbString.Size = new Size(271, 26);
            tbString.TabIndex = 1;
            tbString.TextChanged += Form1_TextChanged;
            // 
            // tbKeyValue
            // 
            tbKeyValue.Location = new Point(286, 188);
            tbKeyValue.Name = "tbKeyValue";
            tbKeyValue.PlaceholderText = "between -25 and 25";
            tbKeyValue.Size = new Size(270, 26);
            tbKeyValue.TabIndex = 2;
            tbKeyValue.TextChanged += Form1_TextChanged;
            // 
            // lblShiftValue
            // 
            lblShiftValue.AutoSize = true;
            lblShiftValue.Font = new Font("Roboto", 12F);
            lblShiftValue.Location = new Point(129, 189);
            lblShiftValue.Name = "lblShiftValue";
            lblShiftValue.Size = new Size(113, 24);
            lblShiftValue.TabIndex = 3;
            lblShiftValue.Text = "Shift Value ";
            // 
            // lblencryptedString
            // 
            lblencryptedString.AutoSize = true;
            lblencryptedString.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblencryptedString.Location = new Point(285, 282);
            lblencryptedString.Name = "lblencryptedString";
            lblencryptedString.Size = new Size(80, 29);
            lblencryptedString.TabIndex = 4;
            lblencryptedString.Text = "Result";
            // 
            // btnEncrypt
            // 
            btnEncrypt.Font = new Font("Roboto Condensed", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnEncrypt.Location = new Point(432, 242);
            btnEncrypt.Name = "btnEncrypt";
            btnEncrypt.Size = new Size(125, 26);
            btnEncrypt.TabIndex = 5;
            btnEncrypt.Text = "Encrypt";
            btnEncrypt.UseVisualStyleBackColor = true;
            btnEncrypt.Click += btnEncrypt_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Roboto", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(236, 8);
            label1.Name = "label1";
            label1.Size = new Size(279, 41);
            label1.TabIndex = 6;
            label1.Text = "String Encryption";
            // 
            // tbResult
            // 
            tbResult.BackColor = SystemColors.Window;
            tbResult.Enabled = false;
            tbResult.Location = new Point(285, 326);
            tbResult.Multiline = true;
            tbResult.Name = "tbResult";
            tbResult.ReadOnly = true;
            tbResult.Size = new Size(271, 25);
            tbResult.TabIndex = 7;
            // 
            // lblError
            // 
            lblError.AutoSize = true;
            lblError.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblError.ForeColor = Color.Red;
            lblError.ImageAlign = ContentAlignment.MiddleLeft;
            lblError.Location = new Point(128, 540);
            lblError.Name = "lblError";
            lblError.Size = new Size(0, 24);
            lblError.TabIndex = 8;
            // 
            // btnClear
            // 
            btnClear.Font = new Font("Roboto Condensed", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnClear.Location = new Point(473, 499);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(82, 26);
            btnClear.TabIndex = 9;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // tbInputCode
            // 
            tbInputCode.BackColor = SystemColors.Window;
            tbInputCode.Enabled = false;
            tbInputCode.Location = new Point(285, 386);
            tbInputCode.Multiline = true;
            tbInputCode.Name = "tbInputCode";
            tbInputCode.ReadOnly = true;
            tbInputCode.Size = new Size(271, 50);
            tbInputCode.TabIndex = 10;
            // 
            // tbOutputCode
            // 
            tbOutputCode.BackColor = SystemColors.Window;
            tbOutputCode.Enabled = false;
            tbOutputCode.Location = new Point(285, 441);
            tbOutputCode.Multiline = true;
            tbOutputCode.Name = "tbOutputCode";
            tbOutputCode.ReadOnly = true;
            tbOutputCode.Size = new Size(271, 54);
            tbOutputCode.TabIndex = 11;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Roboto", 12F);
            label3.Location = new Point(128, 399);
            label3.Name = "label3";
            label3.Size = new Size(108, 24);
            label3.TabIndex = 13;
            label3.Text = "Input ASCII";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Roboto", 12F);
            label2.Location = new Point(128, 327);
            label2.Name = "label2";
            label2.Size = new Size(144, 24);
            label2.TabIndex = 14;
            label2.Text = "Encoded String";
            label2.Click += label2_Click_1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Roboto", 12F);
            label4.Location = new Point(128, 456);
            label4.Name = "label4";
            label4.Size = new Size(124, 24);
            label4.TabIndex = 15;
            label4.Text = "Output ASCII";
            // 
            // tbSortedString
            // 
            tbSortedString.BackColor = SystemColors.Window;
            tbSortedString.Enabled = false;
            tbSortedString.Location = new Point(285, 356);
            tbSortedString.Multiline = true;
            tbSortedString.Name = "tbSortedString";
            tbSortedString.ReadOnly = true;
            tbSortedString.Size = new Size(271, 25);
            tbSortedString.TabIndex = 16;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Roboto", 12F);
            label5.Location = new Point(128, 357);
            label5.Name = "label5";
            label5.Size = new Size(127, 24);
            label5.TabIndex = 17;
            label5.Text = "Sorted String";
            // 
            // CBEncryptMethod
            // 
            CBEncryptMethod.FormattingEnabled = true;
            CBEncryptMethod.Items.AddRange(new object[] { "Caesar Cipher", "Vigenère Cipher" });
            CBEncryptMethod.Location = new Point(286, 84);
            CBEncryptMethod.Name = "CBEncryptMethod";
            CBEncryptMethod.Size = new Size(271, 26);
            CBEncryptMethod.TabIndex = 18;
            CBEncryptMethod.SelectedIndexChanged += CBEncryptMethod_SelectedIndexChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Roboto", 12F);
            label6.Location = new Point(129, 85);
            label6.Name = "label6";
            label6.Size = new Size(78, 24);
            label6.TabIndex = 19;
            label6.Text = "Method";
            label6.Click += label6_Click;
            // 
            // lblStringError
            // 
            lblStringError.AutoSize = true;
            lblStringError.Font = new Font("Roboto SemiBold", 8F, FontStyle.Bold);
            lblStringError.ForeColor = Color.Red;
            lblStringError.Location = new Point(286, 154);
            lblStringError.Name = "lblStringError";
            lblStringError.RightToLeft = RightToLeft.Yes;
            lblStringError.Size = new Size(0, 17);
            lblStringError.TabIndex = 20;
            // 
            // lblKeyValueError
            // 
            lblKeyValueError.AutoSize = true;
            lblKeyValueError.Font = new Font("Roboto SemiBold", 8F, FontStyle.Bold);
            lblKeyValueError.ForeColor = Color.Red;
            lblKeyValueError.Location = new Point(286, 217);
            lblKeyValueError.Name = "lblKeyValueError";
            lblKeyValueError.Size = new Size(0, 17);
            lblKeyValueError.TabIndex = 21;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(706, 584);
            Controls.Add(lblKeyValueError);
            Controls.Add(lblStringError);
            Controls.Add(label6);
            Controls.Add(CBEncryptMethod);
            Controls.Add(label5);
            Controls.Add(tbSortedString);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(tbOutputCode);
            Controls.Add(tbInputCode);
            Controls.Add(btnClear);
            Controls.Add(lblError);
            Controls.Add(tbResult);
            Controls.Add(label1);
            Controls.Add(btnEncrypt);
            Controls.Add(lblencryptedString);
            Controls.Add(lblShiftValue);
            Controls.Add(tbKeyValue);
            Controls.Add(tbString);
            Controls.Add(lblString);
            Font = new Font("Roboto Condensed", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Name = "Form1";
            Text = "String Encryption";
            TextChanged += Form1_TextChanged;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblString;
        private TextBox tbString;
        private TextBox tbKeyValue;
        private Label lblShiftValue;
        private Label lblencryptedString;
        private Button btnEncrypt;
        private Label label1;
        private TextBox tbResult;
        private Label lblError;
        private Button btnClear;
        private TextBox tbInputCode;
        private TextBox tbOutputCode;
        private Label label3;
        private Label label2;
        private Label label4;
        private TextBox tbSortedString;
        private Label label5;
        private ComboBox CBEncryptMethod;
        private Label label6;
        private Label lblStringError;
        private Label lblKeyValueError;
    }
}
