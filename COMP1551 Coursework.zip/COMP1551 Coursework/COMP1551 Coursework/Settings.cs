﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMP1551_Coursework
{
    internal class Settings
    {
        // Form1.cs settings
        // messages
        public string CapitalOnlyMessage = "Only capital letters and no space";
        public string MaxStringMessage = "Length is only 40";
        public string ShiftValueErrorMessage = "Range is between -25 and 25";
        public string KeywordErrorMessage = "Only capital keyword";
        public string KeywordLengthErrorMessage = "Keyword must be shorther or equal";

        // StringProccessing.cs settings
        public int StringMaxLength = 40;
        public int MaxShiftingValue = 25;
        public int MinShiftingValue = -25;
    }
}
